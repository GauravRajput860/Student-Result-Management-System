import sqlite3

con = sqlite3.connect("srms.db")
cur = con.cursor()

cur.execute("DROP TABLE IF EXISTS employee")
cur.execute("""
CREATE TABLE employee (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    f_name TEXT,
    l_name TEXT,
    contact TEXT,
    email TEXT UNIQUE,
    question TEXT,
    answer TEXT,
    password TEXT
)
""")
con.commit()
con.close()
print("Employee table created successfully!")
