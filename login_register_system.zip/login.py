import sqlite3

def log_in():
    email = input("Email: ")
    password = input("Password: ")

    con = sqlite3.connect("srms.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM employee WHERE email=? AND password=?", (email, password))
    row = cur.fetchone()
    con.close()

    if row:
        print("Login successful!")
    else:
        print("Invalid email or password.")

log_in()
