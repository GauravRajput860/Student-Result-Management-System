import sqlite3

def register_user():
    f_name = input("First Name: ")
    l_name = input("Last Name: ")
    contact = input("Contact: ")
    email = input("Email: ")
    question = input("Security Question: ")
    answer = input("Answer: ")
    password = input("Password (min 8 chars): ")

    if len(password) < 8:
        print("Password must be at least 8 characters.")
        return

    con = sqlite3.connect("srms.db")
    cur = con.cursor()
    try:
        cur.execute("INSERT INTO employee (f_name, l_name, contact, email, question, answer, password) VALUES (?, ?, ?, ?, ?, ?, ?)", 
                    (f_name, l_name, contact, email, question, answer, password))
        con.commit()
        print("User registered successfully!")
    except sqlite3.IntegrityError:
        print("Error: Email already exists.")
    con.close()

register_user()
